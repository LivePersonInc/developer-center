var express = require('express');
var app = express();

app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

app.get('/', function (request, response) {
    response.render('pages/index');
});
app.get('/test', function (request, response) {
    var txt = " agent name: " + request.query.agent_name + "\n\n";
    txt += " lead name: " + request.query.name + "\n\n";
    txt += " email: " + request.query.email + "\n\n";
    txt += " telephone: " + request.query.telephone + "\n\n";
    txt += " transcript: " + request.query.transcript + "\n\n";
    var sendgrid = require('sendgrid')('Your Username', 'Your Password');
    var email = new sendgrid.Email({
        to: 'swestover@liveperson.com',
        from: 'you@yourself.com',
        subject: 'Subject goes here',
        text: txt
    });
    sendgrid.send(email, function (err, json) {
        if (err) {
            return console.error(err);
        }
        console.log(json);
    });
    response.render('pages/test');
});
app.listen(app.get('port'), function () {
    console.log('Node app is running on port', app.get('port'));
});

var express = require('express');
var app = express();
var request = require('request');
var lead;
app.set('port', (process.env.PORT || 5000));

app.use(express.static(__dirname + '/public'));

// views is directory for all template files
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.all('/', function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "X-Requested-With");
    next();
});
app.get('/', function (request, response) {
    response.render('pages/index');
});
app.get('/leads', function (request, response) {
    response.render('pages/viewleads');
});
app.post('/getlead',function (req, response) {
     //get the access token for the rest API
    var getTokenURL = "{Your REST URL}/identity/oauth/token?grant_type=client_credentials&client_id={Your ID}&client_secret={Your Secret}";
     //access token for rest api
    var token;
    // email for lead
    var email = req.query.email;
    console.log(email);
    //get the access token
    request.get({
        url: getTokenURL,
        json: true,
        headers: {
            'Content-Type': 'application/json'
        }
    }, function (e, r, b) {
        var obj = b;
        token = obj["access_token"];
        var url = '{Your REST URL}/rest/v1/leads.json?filterType=email&filterValues='+email+'&access_token=' + token;
        //create the lead data in marketo
        request.get({
            url: url,
            json: true,
            headers: {
                'Content-Type': 'application/json'
            }
        }, function (e, r, b) {
            lead = b;
            response.json(lead);
        });
    });
});
app.get('/createLead', function (req, res) {
    //get the access token for the rest API
   var getTokenURL = "{Your REST URL}/identity/oauth/token?grant_type=client_credentials&client_id={Your ID}&client_secret={Your Secret}";
    //access token for rest api
    var token;
    //body parameters for creating a lead in marketo
    var qs = {
        "action": "createOnly",
        "lookupField": "email",
        "input": [
            {
                "email": req.query.email,
                "firstName": req.query.name,
                "phone": req.query.phone
            }
        ]
    };
    //get the access token
    request.get({
        url: getTokenURL,
        json: true,
        headers: {
            'Content-Type': 'application/json'
        }
    }, function (e, r, b) {
        var obj = b;
        token = obj["access_token"];
        var url = '{Your REST URL}/rest/v1/leads.json?access_token=' + token;
        //create the lead data in marketo
        request.post({
            url: url,
            body: qs,
            json: true,
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        }, function (e, r, b) {
            res.json({
                body: b,
            });
        });
    });

});

app.listen(app.get('port'), function () {
    console.log('Node app is running on port', app.get('port'));
});

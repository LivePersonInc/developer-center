package sendgrid;

import ehapi.myframe;

public class SendGridExample {
	  public static void main(String[] args, String body, String agentEmail, String agentName, String apikey, String toemail, myframe frame) {
		    SendGrid sendgrid = new SendGrid(apikey);

		    SendGrid.Email email = new SendGrid.Email();
		    email.addTo(toemail);
		    email.setFrom("lowcsat@test.com");
		    email.setSubject("Transcript from: "+agentName);
		    email.setHtml("Greetings, <br><br>Please find below your transcript:<br><br>"
                    + body);

		    try {
		      SendGrid.Response response = sendgrid.send(email);
		      System.out.println(response.getMessage());
		      frame.setText(response.getMessage());
		    }
		    catch (SendGridException e) {
		      System.err.println(e);
		    }
		  }
		}

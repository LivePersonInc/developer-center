package ehapi;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;

import javax.mail.internet.AddressException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.jsoup.Jsoup;
import org.scribe.builder.ServiceBuilder;
import org.scribe.model.OAuthRequest;
import org.scribe.model.Response;
import org.scribe.model.Token;
import org.scribe.model.Verb;
import org.scribe.oauth.OAuthService;

import sendgrid.SendGridExample;

public class LiveEngageChats {
		static myframe frame = new myframe();
		static ArrayList<String> apiInfo = new ArrayList<String>();
		
	public static void main(String[] args) throws IOException {
		//show output frame
		createandshowGUI();
		//get proerties
		APIGetPropertyValues properties = new APIGetPropertyValues();
		apiInfo = properties.getPropValues();
		
		//below, we are using todays date, and then converting the date back to midnight that way we are consistently pulling
		//a clean set of records
		//we then convert the time to UTC that way it matches the api timezone
		LocalDateTime now = LocalDateTime.now(); 
		LocalDateTime midnight = now.toLocalDate().atStartOfDay();
		ZoneId zoneId = ZoneId.of("UTC"); 
		long epoch = midnight.atZone(zoneId).toInstant().toEpochMilli();
		System.out.println(epoch);
		
		//to change the date range change minuDays function below. For example change 1 to 2 for two days
		LocalDateTime before = midnight.minusDays(1);
		long epoch2 = before.atZone(zoneId).toInstant().toEpochMilli();
		System.out.println(epoch2);
		callAPI(epoch,epoch2);
	 }
	
	public static void callAPI(long epoch, long epoch2){
		//we define a count variable as a way to keep looping through all of the records until we have a complete set for the data range we are pulling
		//we have to do this since there is a limit to the api for how many records we can grab at a time
		long count = 0;
		int limit = 100;
		int offset = 0;
		
		//we are using the scribe package to generate our oauth header for the post request
		//you need to update the api key and secret below with yours
		OAuthService service = new ServiceBuilder()
				 	.provider(LPAPI.class)
	                .apiKey(apiInfo.get(0))
	                .apiSecret(apiInfo.get(1))
	                .build();
		
		//you need to update the token below with your information
		 Token accessToken = new Token(apiInfo.get(2),
				 apiInfo.get(3));
		 
		 //initial request to the api
		 OAuthRequest request = new OAuthRequest(Verb.POST, "https://"+apiInfo.get(4)+"/interaction_history/api/account/"+apiInfo.get(5)+"/interactions/search?offset=0&limit=100");
		 request.addHeader("Content-Type", "application/json");
		 request.addPayload("{\"interactive\":true,\"start\":{\"from\":"+epoch2+",\"to\":"+epoch+"},\"keyword\":\""+apiInfo.get(8)+"\"}");
		 //request.addPayload("{\"interactive\":true,\"start\":{\"from\":1438732800000,\"to\":1439164800000}}");
		 //request.addPayload("{\"interactive\":true,\"start\":{\"from\":1438646400000,\"to\":1438905600000},\"keyword\":\""+apiInfo.get(8)+"\"}");
		 service.signRequest(accessToken, request);
		 Response response = request.send();
		 JSONObject obj =  new JSONObject(response.getBody());
		 System.out.println(response.getMessage());
		 if(response.getMessage().equals("OK")){
			 frame.setText(response.getMessage());
		 count = obj.getJSONObject("_metadata").getLong("count");
		 frame.setText("There are:" + count + " chats.");
		 //keep making api calls until we have a full set of records
		 while(offset < count){
			 offset = offset + limit;
			 OAuthRequest request2 = new OAuthRequest(Verb.POST, "https://"+apiInfo.get(4)+"/interaction_history/api/account/"+apiInfo.get(5)+"/interactions/search?offset="+offset+"&limit=100");
			 request2.addHeader("Content-Type", "application/json");
			 request2.addPayload("{\"interactive\":true,\"start\":{\"from\":"+epoch2+",\"to\":"+epoch+"},\"keyword\":\""+apiInfo.get(8)+"\"}");
			 service.signRequest(accessToken, request2);
			 Response response2 = request2.send();
			 JSONObject obj2 =  new JSONObject(response2.getBody());
			 if(obj2.has("interactionHistoryRecords")){
				 if(obj2.getJSONArray("interactionHistoryRecords").length() != 0){
					 for(int i = 0; i < obj2.getJSONArray("interactionHistoryRecords").length(); i++){
						 obj.getJSONArray("interactionHistoryRecords").put(obj2.getJSONArray("interactionHistoryRecords").get(i));
					 }
				 }
			 }
		 }
		 try {
			sendEachChat(obj);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
		 else{
			 frame.setText(response.getMessage());
		 }
	}
	
	//loop through all of the interaction records and send an email for each chat
	public static void sendEachChat(JSONObject obj) throws AddressException{
		JSONArray allChats = new JSONArray();
		String chat = new String();
		String chatline = new String();
		String agentName = new String();
		String agentEmail = new String();
		
		for(int m = 0; m < obj.getJSONArray("interactionHistoryRecords").length(); m++){
		//int m = 0;
		chat = "";
			allChats.put(obj.getJSONArray("interactionHistoryRecords").getJSONObject(m));
	    	 
			//get the agent information
			agentName = allChats.getJSONObject(m).getJSONObject("info").getString("agentNickName");
			agentEmail = allChats.getJSONObject(m).getJSONObject("info").getString("agentLoginName");
			
			//get the general information on the chat such agent id, skill id, and duration
			chat += "Info <br>";
	    	 for(int n = 0; n < allChats.getJSONObject(m).getJSONObject("info").names().length(); n++){
	    		 chat += "&#160;&#160;&#160;"+allChats.getJSONObject(m).getJSONObject("info").names().getString(n)+ " : "+ allChats.getJSONObject(m).getJSONObject("info").get(allChats.getJSONObject(m).getJSONObject("info").names().getString(n)) + "<br>";
	    	 }
	    	 
	    	 //get the chat transcript lines
	    	 chat += "Transcript <br>";
	    	 for(int p = 0; p < allChats.getJSONObject(m).getJSONObject("transcript").getJSONArray("lines").length(); p++){
	    		 chatline = html2text((String) allChats.getJSONObject(m).getJSONObject("transcript").getJSONArray("lines").getJSONObject(p).get("text"));
	    		 chat += "&#160;&#160;&#160;Time: "+allChats.getJSONObject(m).getJSONObject("transcript").getJSONArray("lines").getJSONObject(p).get("time")+"  By: "+allChats.getJSONObject(m).getJSONObject("transcript").getJSONArray("lines").getJSONObject(p).get("by")+"  Text: "+chatline+"<br>";
	    	 }
	    	 
	    	 //get the chat survey information
	    	 if(obj.getJSONArray("interactionHistoryRecords").getJSONObject(m).has("surveys")){
		    	 chat += "Surveys <br>";
		    	 
		    	 //see if prechat survey exists
				if(allChats.getJSONObject(m).getJSONObject("surveys").has("preChat")){
					chat += "&#160;&#160;&#160;Pre-Chat <br>";
			    	 for(int p = 0; p<allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("preChat").length(); p++){
			    		 chat += "&#160;&#160;&#160;&#160;&#160;&#160;Question: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("preChat").getJSONObject(p).get("displayName")+"  Answer: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("preChat").getJSONObject(p).get("value")+"<br>";
			    	 }
				}
				
				//see if post chat survey exists
				if(allChats.getJSONObject(m).getJSONObject("surveys").has("postChat")){
					chat += "&#160;&#160;&#160;Post Chat <br>";
			    	 for(int p = 0; p<allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("postChat").length(); p++){
			    		 chat += "&#160;&#160;&#160;&#160;&#160;&#160;Question: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("postChat").getJSONObject(p).get("displayName")+"  Answer: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("postChat").getJSONObject(p).get("value")+"<br>";
			    	 }
				}
				
				//see if operator survey exists
				if(allChats.getJSONObject(m).getJSONObject("surveys").has("operator")){
					chat += "&#160;&#160;&#160;Operator <br>";
			    	 for(int p = 0; p<allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("operator").length(); p++){
			    		 chat += "&#160;&#160;&#160;&#160;&#160;&#160;Question: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("operator").getJSONObject(p).get("displayName")+"  Answer: "+allChats.getJSONObject(m).getJSONObject("surveys").getJSONArray("operator").getJSONObject(p).get("value")+"<br>";
			    	 }
				}
			}
	    	 
	    	// get the engagement attributes 
	    	 if(obj.getJSONArray("interactionHistoryRecords").getJSONObject(m).has("sdes")){
	    		 chat += "Engagement Attributes";
	    		 for(int p = 0; p < allChats.getJSONObject(m).getJSONObject("sdes").getJSONArray("events").length(); p++){
	    			 String sde = allChats.getJSONObject(m).getJSONObject("sdes").getJSONArray("events").getJSONObject(p).toString();
	    			 String result = sde.replaceAll(":\\{","<br>&#160;&#160;&#160;" ).replaceAll("\\{", "<br>").replaceAll(",", "<br>&#160;&#160;&#160;").replace("}", "");
	    			 chat += result;
	    		 }
	    	 }
	    	
			SendGridExample.main(null, chat, agentEmail, agentName,apiInfo.get(6),apiInfo.get(7),frame);
			
			//status update of emails sent
			System.out.println("Email "+(m+1)+" of "+obj.getJSONArray("interactionHistoryRecords").length()+" sent.");
			frame.setText("Email "+(m+1)+" of "+obj.getJSONArray("interactionHistoryRecords").length()+" sent.");
		}
		//print confirmation	
		System.out.println("Done");
		frame.setText("Done");
	}
	
	//Used to remove html elements from the chat lines.
	public static String html2text(String html) {
	    return Jsoup.parse(html).text();
	}
	//show frame for output
		private static void createandshowGUI()
		{
			frame.setVisible(true);
		}
}

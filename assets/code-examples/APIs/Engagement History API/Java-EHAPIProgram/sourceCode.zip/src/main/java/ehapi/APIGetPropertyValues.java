package ehapi;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Properties;

public class APIGetPropertyValues {
	InputStream inputStream;
 
	public ArrayList<String> getPropValues() throws IOException {
		ArrayList<String> properties = new ArrayList<String>();
		try {
			Properties prop = new Properties();
			//String propFileName = "./config.properties";
			String propFileName = "config.properties";
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
			// get the property valu
			properties.add(prop.getProperty("apikey"));
			properties.add(prop.getProperty("apisecret"));
			properties.add(prop.getProperty("tokenkey"));
			properties.add(prop.getProperty("tokensecret"));
			properties.add(prop.getProperty("baseuri"));
			properties.add(prop.getProperty("accountnum"));
			properties.add(prop.getProperty("sendgridapi"));
			properties.add(prop.getProperty("sendtoemail"));
			properties.add(prop.getProperty("keyword"));
 
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		} finally {
			inputStream.close();
		}
		return properties;
	}
}
